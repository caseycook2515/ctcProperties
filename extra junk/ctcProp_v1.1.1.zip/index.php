<?php 
// bootlogin.php
?>
<!DOCTYPE html>
<html>
	<head>
		<title>CTC Properties</title>
	</head>
	<body>
		<h1>CTC Properties</h1>
		<p>Info about CTC Properties.</p>

	</body>
</html>