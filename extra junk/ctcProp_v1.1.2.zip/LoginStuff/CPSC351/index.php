<!DOCTYPE html>
<html>
	<head>
		<title>Casey's App</title>
	</head>
	<body>
		<h2>Hello World.</h2>
		<h3><?php  
// variable
$first = "Casey";
$last = 'Cook';
$msg = "Welcome, $first $last.\n<br />";
print $msg;				
		
		?></h3>
	</body>
</html>	
